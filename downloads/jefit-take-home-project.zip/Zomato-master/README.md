# Jefit Take Home Project

## Demo

https://youtu.be/0QEJmfLTXP8


## App Architecture

I chose Swift since it is the modern iOS programming launguage. The app is using standard iOS MVC pattern with storyboard. The app uses `SQLite3`, `UserDefault`, `NSKeyedArchive` to store data to demonstrate the skills. The app uses Apple network framework to communicate with backend API and uses `Codable` to decode the response.

### UI

The app uses storyboard with resusable xib 

The app has following screens,

- Add a city
  - The user can search and add a city
- City list (home screen)
  - All cities that added by the user are displayed here
- Establishment
  - Top 10 establishments are listed based on the chosen city and the user can choose a establishment
- Restaurant
  - Top 15 restaurants are listed based on the chosen city and establishment.
- Restaurant Details
  - Top 15 photos are displayed in collection view
  
```
Add a city
  ^
  | (Present)
  |
  |       push                push             push
City List ----> Establishment ----> Restaurant ----> Restaurant Details

```

### Image Cache

Reference class: `ImageCache.swift`

The app cached all images from the network to provide fast loading  speed and reduce the server loads. I didn't choose to use a third party  library to demonstrate my understanding of image cache. Due to the time limit, the image disk cache was implemented relatively simple.

The concept is to create a Dictionary that maps URL string to file name.
- The dictionary is stored locally by using `NSKeyedArchiver` to store locally
- If the image can be found locally, just return the image on the disk
- If the image can't be found locally, it requests and saves the image on the disk, then return the image
- NOTE: The cache is implemented relatively simple and it misses many features, like compression, purge strategy, performance optimization ( how mapping table read and writes)

### Local Database

#### Cities Store

Reference class: `DatabaseStore.swift`, `DatabaseStore+City`

The local database is used for storing user's selected cities. I like SQLite3 over Core Data because

- Safe access from multiple processes and threads
- Small and lightweight
- Decouple with data model
- Less memory and storage usage
- SQLite schema can be used on Android
- SQLite/SQL documentation is very easy to find
- Have fully control

Since it directly interacts with C API and it might cause bugs for type  conversion, like Swift string to C string. In long term, we should make a generic Swift API and encapsulate the low level interactions

#### Liked Restaurant Store

Reference class: `FavoriteRestaurantStore.swift`

I chose `UserDefault` to store likes. I store all liked restaurant IDs in an array and associate a key with it.

Note:
To avoid checking if `contains` costs `o(n)` for the time complexity, I convert it to the set and store in the memory. Set does `o(1)` for `contains` check.

### Network Manager

`NetworkManager.swift` should cover enough documeentation. In the long term, we should consider depeendency injection in order to enable mock network response.

### Unit Test/UI Test

Due to the limitation of the team, I am unable to complete this part.

### Questions?

feng.guo.aus@gmail.com
