//
//  AddCityViewController.swift
//  Zomato
//
//  Created by Feng Guo on 15/2/20.
//  Copyright © 2020 Feng Guo. All rights reserved.
//

import UIKit

protocol SelectedDelegate: class {
    func citySelected(selectedCity: City)
}

class AddCityViewController: UIViewController {
    
    fileprivate let cellIdentifier = "CityCell"

    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var tableView: UITableView!
    
    fileprivate var cities = [City]()
    
    private let activityIndicator = UIActivityIndicatorView(style: .medium)
    
    weak var delegate: SelectedDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Add a City"
        navigationItem.leftBarButtonItem = UIBarButtonItem(barButtonSystemItem: .cancel, target: self, action: #selector(cancelTapped))
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: activityIndicator)
        tableView.register(UINib(nibName: String(describing: CityTableViewCell.self), bundle: nil), forCellReuseIdentifier: cellIdentifier)
        
        activityIndicator.hidesWhenStopped = true
    }
    
    @objc private func cancelTapped() {
        dismiss(animated: true, completion: nil)
    }
    
    func requestCities(_ queryString: String) {
        self.activityIndicator.startAnimating()
        NetworkManager.requestCity(queryString) { (cities) in
            DispatchQueue.main.async {
                self.activityIndicator.stopAnimating()
                
                guard cities.count > 0 else {
                    let alertController = UIAlertController(title: "No result was found", message: "", preferredStyle: .alert)
                    alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                    self.present(alertController, animated: true, completion: nil)
                    return
                }
                self.cities = cities
                self.tableView.reloadData()
            }
        }
    }
}

extension AddCityViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let city = cities[indexPath.row]
        self.delegate?.citySelected(selectedCity: city)
        self.dismiss(animated: true, completion: nil)
    }
    
}

extension AddCityViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cities.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? CityTableViewCell else {
            return UITableViewCell()
        }
        
        let city = cities[indexPath.row]
        cell.city.text = city.cityName
        cell.country.text = city.countryName
        cell.flag.zo_setImage(imageURL: city.flagURL)
        
        return cell
    }
}

extension AddCityViewController: UISearchBarDelegate {
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
        guard let queryString = searchBar.text?.replacingOccurrences(of: " ", with: "%20") else {
            return
        }
        requestCities(queryString)
        
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.text = ""
        tableView.reloadData()
    }
}
