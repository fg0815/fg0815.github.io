//
//  CityTableViewCell.swift
//  Zomato
//
//  Created by Feng Guo on 16/2/20.
//  Copyright © 2020 Feng Guo. All rights reserved.
//

import UIKit

class CityTableViewCell: UITableViewCell {

    @IBOutlet weak var flag: UIImageView!
    
    @IBOutlet weak var city: UILabel!
    
    @IBOutlet weak var country: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
}
