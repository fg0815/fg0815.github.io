//
//  ViewController.swift
//  Zomato
//
//  Created by Feng Guo on 2/15/20.
//  Copyright © 2020 Feng Guo. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController {

    fileprivate let SelectedCityCellIdentifier =  "SelectedCityCellIdentifier"
    fileprivate let CityToEstablishmentSegueIdentifier = "CityToEstablishment"

    @IBOutlet weak var tableView: UITableView!
    
    fileprivate var cities = [City]()

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.register(
            UINib(
                nibName: String(describing: CityTableViewCell.self),
                bundle: nil),
            forCellReuseIdentifier: SelectedCityCellIdentifier)

        cities = DatabaseStore.shared.retrieveCities()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let indexPath = self.tableView.indexPathForSelectedRow else {
            return
        }
        
        let city = cities[indexPath.row]
        
        if segue.identifier == CityToEstablishmentSegueIdentifier {
            let establishmentVC = segue.destination as? EstablishmentViewController
            establishmentVC?.city = city
        }
    }

    // MARK: - private

    @IBAction private func addCity(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        guard let addCityVC = storyboard.instantiateViewController(
            withIdentifier: String(describing: AddCityViewController.self)) as? AddCityViewController else {
                fatalError("Unabble to find `AddCityViewController` in Storyboard")
        }

        addCityVC.delegate = self
        
        let navigationController = UINavigationController(rootViewController: addCityVC)
        self.navigationController?.present(navigationController, animated: true, completion: nil)
    }
}

extension HomeViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.performSegue(withIdentifier: CityToEstablishmentSegueIdentifier, sender: nil)
        
        tableView.deselectRow(at: indexPath, animated: true)
    }
}

extension HomeViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        tableView.separatorStyle = cities.count == 0 ? .none : .singleLine
        
        return cities.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: SelectedCityCellIdentifier, for: indexPath) as? CityTableViewCell else {
            fatalError("CityTableViewCell is unable to dequeue?")
        }

        let city = cities[indexPath.row]

        cell.city.text = city.cityName
        cell.country.text = city.countryName
        cell.flag.zo_setImage(imageURL: city.flagURL)

        return cell
    }
}

extension HomeViewController: SelectedDelegate {
    func citySelected(selectedCity: City) {
        cities.append(selectedCity)
        tableView.reloadData()

        DatabaseStore.shared.insert(city: selectedCity)
    }
}

