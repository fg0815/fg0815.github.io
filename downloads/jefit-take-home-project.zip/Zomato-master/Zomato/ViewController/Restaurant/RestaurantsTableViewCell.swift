//
//  RestuarantsTableViewCell.swift
//  Zomato
//
//  Created by Feng Guo on 17/2/20.
//  Copyright © 2020 Feng Guo. All rights reserved.
//

import UIKit

class RestaurantsTableViewCell: UITableViewCell {
    
    private let imageButton = "like_outline"
    private let selectedImageButton = "like_filled"

    @IBOutlet weak var thumbnailImage: UIImageView!
    @IBOutlet weak var restaurantName: UILabel!
    @IBOutlet weak var restaurantAddress: UILabel!
    @IBOutlet weak var restaurantCuisine: UILabel!
    @IBOutlet weak var likeImage: UIImageView!
    @IBOutlet weak var likeButton: UIButton!
    
    var restaurantID: String?
    
    private var isLiked = false
    
    func updateLikeButton(isSelected: Bool) {
        isLiked = isSelected
        
        let image = UIImage(named: isSelected ? selectedImageButton : imageButton)
        likeImage.image = image?.withRenderingMode(.alwaysTemplate).withTintColor(.green)
    }
    
    @IBAction func likeAction(_ sender: Any) {
        isLiked = !isLiked
        updateLikeButton(isSelected: isLiked)
        
        guard let restaurantID = restaurantID else {
            return
        }
        
        if isLiked {
            FavoriteRestaurantStore().likeRestaurant(restaurantID: restaurantID)
        } else {
            FavoriteRestaurantStore().dislikeRestaurant(restaurantID: restaurantID)
        }
    }
    
}
