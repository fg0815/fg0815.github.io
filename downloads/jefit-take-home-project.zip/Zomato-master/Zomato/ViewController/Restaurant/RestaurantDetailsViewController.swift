//
//  RestaurantDetailsViewController.swift
//  Zomato
//
//  Created by Feng Guo on 17/2/20.
//  Copyright © 2020 Feng Guo. All rights reserved.
//

import UIKit

class RestaurantDetailsViewController: UIViewController {

    @IBOutlet weak var collectionView: UICollectionView!
    
    private let likeButton = UIButton(type: .custom)
    
    var restaurant: Restaurant?
    
    private let collectionViewCellIdentifer = "CollectionViewCellIdentifier"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        likeButton.setImage(UIImage(named: "like_outline")?.withRenderingMode(.alwaysTemplate).withTintColor(.green), for: .normal)
        likeButton.setImage(UIImage(named: "like_filled")?.withRenderingMode(.alwaysTemplate).withTintColor(.green), for: .selected)
        
        likeButton.addTarget(self, action: #selector(likeAction(_:)), for: .touchUpInside)
        
        if let id = restaurant?.id {
            let isSelected = FavoriteRestaurantStore().isRestaurantLiked(restaurantID: id)
            likeButton.isSelected = isSelected
            navigationItem.rightBarButtonItem = UIBarButtonItem(customView: likeButton)
        }
    }
    
    @objc private func likeAction(_ sender: Any) {
        likeButton.isSelected = !likeButton.isSelected
        
        if let id = restaurant?.id {
            if likeButton.isSelected {
                FavoriteRestaurantStore().likeRestaurant(restaurantID: id)
            } else {
                FavoriteRestaurantStore().dislikeRestaurant(restaurantID: id)
            }
        }
    }
    
}

extension RestaurantDetailsViewController: UICollectionViewDelegate {
    // TODO: open the image
}

extension RestaurantDetailsViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return restaurant?.photos.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: collectionViewCellIdentifer, for: indexPath) as! ImageCollectionViewCell

        if let imageURL = restaurant?.photos[indexPath.item].photo.url {
            cell.contentImage.zo_setImage(imageURL: imageURL)
        }
        cell.backgroundColor = .gray
        return cell
    }
}
