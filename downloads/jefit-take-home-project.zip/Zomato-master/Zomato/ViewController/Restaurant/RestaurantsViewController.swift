//
//  RestuarantsViewController.swift
//  Zomato
//
//  Created by Feng Guo on 17/2/20.
//  Copyright © 2020 Feng Guo. All rights reserved.
//

import UIKit

class RestaurantsViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    private let tableViewCellIdentifier = "TableViewCellReusableIdentifier"
    
    var restaurants = [Restaurant]()
    
    var city: City?
    var establishment: Establishment?
    
    private let activityIndicator = UIActivityIndicatorView(style: .medium)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        guard let selectedCityId = city?.id else {
            fatalError("City ID is required to pass in")
        }
        
        guard let selectedEstablishmentId = establishment?.id else {
            fatalError("Establishment ID is required to pass in")
        }
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: activityIndicator)
        activityIndicator.hidesWhenStopped = true
        
        requestRestuarants(with: selectedCityId, establishment: selectedEstablishmentId)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        tableView.reloadData()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let indexPath = self.tableView.indexPathForSelectedRow else {
            return
        }

        let restaurant = restaurants[indexPath.row]

        if segue.identifier == "DetailsIdentifier" {
            let restuarantDetailsVC = segue.destination as? RestaurantDetailsViewController
            restuarantDetailsVC?.restaurant = restaurant
        }
    }
    
    private func requestRestuarants(with cityId: Int, establishment: Int) {
        activityIndicator.startAnimating()
        NetworkManager.requestRestuarants(with: cityId, establishmentId: establishment) { (restaurants) in
            DispatchQueue.main.async {
                self.activityIndicator.stopAnimating()
                self.restaurants = restaurants
                self.tableView.reloadData()
            }
        }
    }
}

extension RestaurantsViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.performSegue(withIdentifier: "DetailsIdentifier", sender: nil)
        
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
}

extension RestaurantsViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return restaurants.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: tableViewCellIdentifier, for: indexPath) as! RestaurantsTableViewCell
        let restaurant = restaurants[indexPath.row]
        cell.restaurantID = restaurant.id
        cell.restaurantName?.text = restaurant.name
        cell.restaurantAddress?.text = restaurant.location.address
        cell.restaurantCuisine?.text = restaurant.cuisines
        cell.updateLikeButton(isSelected: FavoriteRestaurantStore().isRestaurantLiked(restaurantID: restaurant.id))
        
        cell.thumbnailImage.zo_setImage(imageURL: restaurant.thumbnail)

        return cell
    }
}
