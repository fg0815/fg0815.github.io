//
//  EstablishmentViewController.swift
//  Zomato
//
//  Created by Feng Guo on 16/2/20.
//  Copyright © 2020 Feng Guo. All rights reserved.
//

import UIKit

class EstablishmentViewController: UIViewController {
    
    // MARK: - constants
    
    private let cellIdentifier = "TableViewCell"
    private let restaurantsSegueIdentifier =  "RestuarantsIdentifier"
    
    @IBOutlet private weak var tableView: UITableView!
    
    var city: City?
    
    private var establishments = [Establishment]()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Establishments"
        
        guard let selectedCityId = city?.id else {
            fatalError("City ID is required to pass in")
        }
        
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: cellIdentifier)
        
        requestEstablishment(with: selectedCityId)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let indexPath = self.tableView.indexPathForSelectedRow else {
            return
        }

        let establishment = establishments[indexPath.row]

        if segue.identifier == restaurantsSegueIdentifier {
            let restuarantsVC = segue.destination as? RestaurantsViewController
            restuarantsVC?.establishment = establishment
            restuarantsVC?.city = city
        }
    }
    
    private func requestEstablishment(with cityID: Int) {
        NetworkManager.requestEstablishment(with: cityID) { (establishments) in
            // We only get the first 10 establishments
            if establishments.count > 10 {
                self.establishments = Array(establishments[0..<10])
            } else {
                self.establishments = establishments
            }
            
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
    }
}

extension EstablishmentViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.performSegue(withIdentifier: restaurantsSegueIdentifier, sender: nil)
        
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
}

extension EstablishmentViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return establishments.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath)
        let establishment = establishments[indexPath.row]
        cell.textLabel?.text = establishment.name
        cell.accessoryType = .disclosureIndicator
        return cell
    }
}
