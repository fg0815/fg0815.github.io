//
//  Establishment.swift
//  Zomato
//
//  Created by Feng Guo on 16/2/20.
//  Copyright © 2020 Feng Guo. All rights reserved.
//

import Foundation

struct Establishment: Codable {
    let id: Int
    let name: String
    
    enum CodingKeys: String, CodingKey {
        case id = "id"
        case name = "name"
    }
}

struct EstablishmentContainer: Codable {
    let establishment: Establishment
    
    enum CodingKeys: String, CodingKey {
        case establishment = "establishment"
    }
}

struct Establishments: Codable {
    let establishments: [EstablishmentContainer]
    
    enum CodingKeys: String, CodingKey {
        case establishments = "establishments"
    }
}
