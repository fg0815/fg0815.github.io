//
//  Location.swift
//  Zomato
//
//  Created by Feng Guo on 2/17/20.
//  Copyright © 2020 Feng GUo. All rights reserved.
//

import Foundation

struct Location: Codable {
    let address: String
    
    enum CodingKeys: String, CodingKey {
        case address
    }
}
