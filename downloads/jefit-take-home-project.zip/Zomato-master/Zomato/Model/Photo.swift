//
//  File.swift
//  Zomato
//
//  Created by Feng Guo on 2/17/20.
//  Copyright © 2020 Feng Guo. All rights reserved.
//

import Foundation

struct Photo: Codable {
    let url: String
    
    enum CodingKeys: String, CodingKey {
        case url
    }
}

struct PhotoContainer: Codable {
    let photo: Photo
    
    enum CodingKeys: String, CodingKey {
        case photo
    }
}

