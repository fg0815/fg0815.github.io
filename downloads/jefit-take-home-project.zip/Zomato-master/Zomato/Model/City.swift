//
//  City.swift
//  Zomato
//
//  Created by Feng Guo on 16/2/20.
//  Copyright © 2020 Feng Guo. All rights reserved.
//

import Foundation

struct City: Codable {
    let cityName: String
    let countryName: String
    let flagURL: String
    let id: Int
    
    enum CodingKeys: String, CodingKey {
        case cityName = "name"
        case countryName = "country_name"
        case flagURL = "country_flag_url"
        case id = "id"
    }
}

struct Cities: Codable {
    let cities: [City]
    
    enum CodingKeys: String, CodingKey {
        case cities = "location_suggestions"
    }
}
