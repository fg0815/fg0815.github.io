//
//  Restuarant.swift
//  Zomato
//
//  Created by Feng Guo on 17/2/20.
//  Copyright © 2020 Feng Guo. All rights reserved.
//

import Foundation

struct Restaurant: Codable {
    let id: String
    let name: String
    let location: Location
    let cuisines: String
    let thumbnail: String
    let photos: [PhotoContainer]
    
    enum CodingKeys: String, CodingKey {
        case id, name, location, cuisines, photos
        case thumbnail = "thumb"
    }
}

struct RestaurantContainer: Codable {
    let restaurant: Restaurant
    
    enum CodingKeys: String, CodingKey {
        case restaurant
    }
}

struct Restaurants: Codable {
    let restuarants: [RestaurantContainer]
    
    enum CodingKeys: String, CodingKey {
        case restuarants = "restaurants"
    }
}

