//
//  DatabaseStore.swift
//  Zomato
//
//  Created by Feng Guo on 2/17/20.
//  Copyright © 2020 Feng Guo. All rights reserved.
//

import Foundation
import SQLite3

/// SQLite database for added cities
class DatabaseStore {

    static let shared = DatabaseStore()

    /// Get the URL to db store file
    private let dbURL: URL

    /// The database pointer
    var db: OpaquePointer?

    init() {
        do {
            dbURL = try FileManager.default
                .url(for: .cachesDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
                .appendingPathComponent("zomato.db")
        } catch {
            print("[Database] Some error occurred. Returning empty path.")
            dbURL = URL(fileURLWithPath: "")
            return
        }

        openDB()
        createTables()
    }

    /// Command: sqlite3_open(dbURL.path, &db)
    /// Open the DB at the given path. If file does not exists, it will create one for you
    private func openDB() {
        if sqlite3_open(dbURL.path, &db) != SQLITE_OK { // error mostly because of corrupt database
            print("[Database] Error opening database \(dbURL.absoluteString)")
        }
    }

    /// Create default tables
    private func createTables() {
        // create the tables if they dont exist.
        let statemeent = "CREATE TABLE City (CityId INTEGER, CityName TEXT, CountryName TEXT, FlagUrl TEXT, PRIMARY KEY(CityId)); CREATE TABLE Establishment (CityId INTEGER, EstablishmentId INTEGER, Name INTEGER, PRIMARY KEY(EstablishmentId), FOREIGN KEY(CityId) REFERENCES City(CityId));"

        let ret = sqlite3_exec(db, statemeent, nil, nil, nil)
        if (ret != SQLITE_OK) { // corrupt database.
            print("Error creating db table - Records")
        }
    }

}
