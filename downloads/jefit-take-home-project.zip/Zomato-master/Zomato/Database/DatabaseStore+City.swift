//
//  CityDB.swift
//  Zomato
//
//  Created by Feng Guo on 2/17/20.
//  Copyright © 2020 Feng Guo. All rights reserved.
//

import Foundation
import SQLite3

extension DatabaseStore {
    /// Insert a city into database
    func insert(city: City) {
        var statement: OpaquePointer?
        
        let sql = "INSERT INTO City (CityId, CityName, CountryName, FlagUrl) VALUES (?, ?, ?, ?)"

        // preparing the query
        let prepare = sqlite3_prepare(db, sql, -1, &statement, nil)
        if prepare != SQLITE_OK {
            print("[Database] sqlite3_prepare insertEntryStmt")
        }

        defer {
            sqlite3_finalize(statement)
        }

        if sqlite3_bind_int(statement, 1, Int32(city.id)) != SQLITE_OK {
            print("[Database] cityId inserts failed")
            return
        }

        // https://stackoverflow.com/a/28259253
        // Convert String to UTF8String to make sure it inserts the correct value

        if sqlite3_bind_text(statement, 2, (city.cityName as NSString).utf8String, -1, nil) != SQLITE_OK {
            print("[Database] cityName inserts failed")
            return
        }

        if sqlite3_bind_text(statement, 3, (city.countryName as NSString).utf8String, -1, nil) != SQLITE_OK {
            print("[Database] countryName inserts failed")
            return
        }

        if sqlite3_bind_text(statement, 4, (city.flagURL as NSString).utf8String, -1, nil) != SQLITE_OK {
            print("[Database] flagURL inserts failed")
            return
        }

        // executing the query to insert values
        let execute = sqlite3_step(statement)
        if execute != SQLITE_DONE {
            print("[Database] sqlite3_step(insertEntryStmt) \(execute)")
            return
        }
    }

    /// Get all cities from database
    func retrieveCities() -> [City] {
        var statement: OpaquePointer?

        let sql = "SELECT CityId, CityName, CountryName, FlagUrl FROM City"

        // preparing the query
        if sqlite3_prepare(db, sql, -1, &statement, nil) != SQLITE_OK {
            print("[Database] sqlite3_prepare readEntryStmt")
        }

        defer {
            sqlite3_finalize(statement)
        }

        var cities = [City]()

        var r = sqlite3_step(statement)

        while r == SQLITE_ROW {
            let city = City(
                cityName: String(cString: sqlite3_column_text(statement, 1)),
                countryName: String(cString: sqlite3_column_text(statement, 2)),
                flagURL: String(cString: sqlite3_column_text(statement, 3)),
                id: Int(sqlite3_column_int(statement, 0)))
            cities.append(city)

            r = sqlite3_step(statement)
        }

        return cities
    }
}
