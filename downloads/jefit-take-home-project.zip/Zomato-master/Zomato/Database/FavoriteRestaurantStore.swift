//
//  FavoriteRestaurantStore.swift
//  Zomato
//
//  Created by Feng Guo on 2/17/20.
//  Copyright © 2020 Feng Guo. All rights reserved.
//

import Foundation

/// Handle favorite restaurant likes
class FavoriteRestaurantStore {
    
    private static let key = "FavoriteRestaurant"
    
    private var favoriteRestaurants: Set<String>
    
    init() {
        favoriteRestaurants = Set<String>(FavoriteRestaurantStore.storedValues())
    }
    
    func likeRestaurant(restaurantID: String) {
        if !favoriteRestaurants.contains(restaurantID) {
            favoriteRestaurants.insert(restaurantID)
            
            FavoriteRestaurantStore.saveValues(Array(favoriteRestaurants))
        }
    }
    
    func dislikeRestaurant(restaurantID: String) {
        if favoriteRestaurants.contains(restaurantID) {
            favoriteRestaurants.remove(restaurantID)
            
            FavoriteRestaurantStore.saveValues(Array(favoriteRestaurants))
        }
    }
    
    func isRestaurantLiked(restaurantID: String) -> Bool {
        return favoriteRestaurants.contains(restaurantID)
    }
    
    // MARK: - private
    
    private static func storedValues() -> [String] {
        return UserDefaults.standard.value(forKey: key) as? [String] ?? [String]()
    }
    
    private static func saveValues(_ restaurantIDs: [String]) {
        UserDefaults.standard.setValue(restaurantIDs, forKey: key)
    }
    
}
