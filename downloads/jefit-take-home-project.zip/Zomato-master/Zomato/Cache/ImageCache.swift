//
//  ImageCache.swift
//  Zomato
//
//  Created by Feng Guo on 2/17/20.
//  Copyright © 2020 Feng Guo. All rights reserved.
//

import UIKit

/// Extension to have a convenient function to set image on UIImageView
extension UIImageView {

    /// public API to set an image URL into UIImageView
    func zo_setImage(imageURL: String) {
        ImageStorage.shared.retrieveImage(with: imageURL) { (image) in
            self.image = image
        }
    }

}

/// The simple image disk cache
/// The concept is to create a Dictionary that maps URL string to file name.
/// - The dictionary is stored locally by using NSKeyedArchiver to storey locally
/// - If the image can be found locally, just return the image on the disk
/// - If the image can't be found locally, it requests and saves the image on the disk, then return the image
/// - note: The cache is implemented relatively simple and it misses many features, like compression, purge strategy, performance optimization ( how mapping table read and writes)
private class ImageStorage {
    static let documentsDirectory = FileManager().urls(for: .documentDirectory, in: .userDomainMask).first
    static let archiveURL = documentsDirectory?.appendingPathComponent("images")

    static let shared = ImageStorage()

    // dictionary [url: filename]
    private var imageCache: ImageCache

    init() {
        imageCache = ImageStorage.retrieve() ?? ImageCache()
    }

    func retrieveImage(with imageURLString: String, completion: @escaping (UIImage?) -> Void) {
        if let imageFile = imageCache.imageDic[imageURLString] {
            do {
                let fileManager = FileManager.default
                let documentDirectory = try fileManager.url(for: .documentDirectory, in: .userDomainMask, appropriateFor:nil, create:false)
                let fileURL = documentDirectory.appendingPathComponent("\(imageFile).jpg")
                let data = try Data(contentsOf: fileURL)
                let image = UIImage(data: data)
                completion(image)
            } catch {
                // TODO: Handle error here
                print(error)
                completion(nil)
            }

            return
        }

        NetworkManager.requestImage(with: imageURLString) { (image) in
            DispatchQueue.main.async {
                if let image = image {
                    self.saveImage(image, urlString: imageURLString)
                }
                completion(image)
            }
        }
    }

    private func saveImage(_ image: UIImage, urlString: String) {
        let uuid = UUID().uuidString

        // Step 1: Save into disk
        let fileManager = FileManager.default
        do {
            let documentDirectory = try fileManager.url(for: .documentDirectory, in: .userDomainMask, appropriateFor:nil, create:false)
            let fileURL = documentDirectory.appendingPathComponent("\(uuid).jpg")
            if let imageData = image.jpegData(compressionQuality: 1.0) {
                try imageData.write(to: fileURL)
            }
        } catch {
            // TODO: Handle error here
            print(error)
        }

        // Step 2: Save into image cache dictionary
        imageCache.imageDic[urlString] = uuid
        ImageStorage.save(imageCache: imageCache)
    }

    private static func retrieve() -> ImageCache? {
        guard let data = try? Data(contentsOf: ImageStorage.archiveURL!, options: [])
            else {
                print("No data found at the location")
                return nil
        }
        guard let imageCache = try? NSKeyedUnarchiver.unarchiveTopLevelObjectWithData(data) as? ImageCache else {
            print("can't decode")
            return nil
        }
        return imageCache
    }

    private static func save(imageCache: ImageCache) {
        do {
            let writeData = try NSKeyedArchiver.archivedData(withRootObject: imageCache, requiringSecureCoding: false)
            try writeData.write(to: ImageStorage.archiveURL!)
        } catch _ {
            print("failed to save")
        }
    }
}

private struct ImageCachePropertyKey {
    static let imageDic = "imageDic"
}

// Use NSCoding to store custom object
class ImageCache: NSObject, NSCoding {

    // url: filename
    var imageDic: [String: String]

    init(imageDic: [String: String]? = nil) {
        self.imageDic = imageDic ?? [String: String]()
        super.init()
    }

    func encode(with aCoder: NSCoder) {
        aCoder.encode(imageDic, forKey: ImageCachePropertyKey.imageDic)
    }

    required convenience init?(coder aDecoder: NSCoder) {
        guard let imageDic = aDecoder.decodeObject(forKey: ImageCachePropertyKey.imageDic) as? [String: String] else {
            fatalError("can't be decode")
        }
        self.init(imageDic: imageDic)
    }

}

